///
/// SwapMove
///
class SwapMove {
  final int row;
  final int col;
  
  const SwapMove({
    this.row,
    this.col,
  });
}