
import 'package:flutter_crush/application.dart';
import 'package:flutter_crush/helpers/audio.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

void main() {
  //
  // Initialize the audio
  // await Audio.init();
  // SystemChrome.setEnabledSystemUIOverlays([]);

  return runApp(
    Application(),
  );
}