class AppRouteName {
  static const String getStarted = "/get-started";
  static const String home = "/home";
}
