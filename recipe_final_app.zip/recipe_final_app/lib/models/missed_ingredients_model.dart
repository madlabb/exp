/*
class MissedIngredientsModel{

  final String aisle;
  final String amount;
  final String image;
  final String name;
  final String original;

  MissedIngredientsModel({this.image, this.name, this.aisle, this.amount, this.original});

}*/
